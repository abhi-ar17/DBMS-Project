from django.shortcuts import render
from PersonalData.models import Employee
def employee(request):
  empl = Employee.objects.all()
  return render(request, 'employee.html', {'emp':empl})




