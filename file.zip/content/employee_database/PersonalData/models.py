from djongo import models

class Employee(models.Model):
  firstName = models.CharField(max_length = 100)
  lastName = models.CharField(max_length = 100)
  gender = models.CharField(max_length = 8)
  dateOfBirth = models.DateField
  maritalStatus = models.CharField(max_length = 100)

class   
  

